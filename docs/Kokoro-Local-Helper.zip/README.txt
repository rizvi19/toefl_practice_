Setup: https://rizvi19.github.io/toefl_practice_/docs/kokoro.html
Run Launch-Kokoro.cmd using your existing Kokoro Python, model and FFmpeg. No installation or downloads occur. Choose Kokoro in Settings on https://rizvi19.github.io/toefl_practice_/ . Keep the helper running. Only played activities generate; cache limit 20 MB.
